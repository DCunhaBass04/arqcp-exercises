#ifndef FUNCTION_H
#define FUNCTION_H
char verify_flags();
#endif
